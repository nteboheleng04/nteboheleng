package com.example.mediaplay;

import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.fxml.FXML;
import java.io.File;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.FileChooser;
import javafx.util.Duration;

public class HelloController {
    @FXML
    private Label min;
    @FXML
    private Label max;
    @FXML
    private MediaView mediaView;

    @FXML
    private Slider volumeSlider;

    private MediaPlayer mediaPlayer;

    @FXML
    private void handleOpen() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("");
        File file = fileChooser.showOpenDialog(mediaView.getScene().getWindow());
        if (file != null) {
            Media media = new Media(file.toURI().toString());
            mediaPlayer = new MediaPlayer(media);
            mediaView.setMediaPlayer(mediaPlayer);
            mediaView.setFitWidth(1500);
            mediaView.setFitHeight(600);
            mediaPlayer.play();
            
            mediaPlayer.setVolume(volumeSlider.getValue());

            volumeSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
                mediaPlayer.setVolume(newValue.doubleValue());
            });

            Duration duration = mediaPlayer.getMedia().getDuration();

            mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
                double currentTime = newValue.toSeconds();
                int minutes = (int) currentTime / 60;
                int seconds = (int) currentTime % 60;
                min.setText(String.format("%02d:%02d", minutes, seconds));
            });
            mediaPlayer.setOnReady(() -> {
                Duration total = mediaPlayer.getTotalDuration();
                double totalSeconds = total.toSeconds();
                int minutes = (int) totalSeconds / 60;
                int seconds = (int) totalSeconds % 60;
                max.setText(String.format("%02d:%02d", minutes, seconds));
            });
        }
    }
    @FXML
    private void handleExit() {
        System.exit(0);
    }
    @FXML
    private void handlePlay() {
        mediaPlayer.play();
    }
    @FXML
    private void handlePause() {
        mediaPlayer.pause();
    }
    @FXML
    private void handleStop() {
        mediaPlayer.stop();
    }
}
